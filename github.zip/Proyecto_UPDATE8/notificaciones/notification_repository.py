import os
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # carpeta padre del paquete actual
DATA_DIR = os.path.join(BASE_DIR, "data")               # carpeta data
RUTA = os.path.join(DATA_DIR, "notificaciones.json")    # ruta final del JSON

class NotificationRepository:

    def __init__(self):
        self.ensure_file()

    def ensure_file(self):
        # Crear carpeta data si no existe
        if not os.path.exists(DATA_DIR):
            try:
                os.makedirs(DATA_DIR)
                logger.info(f"Carpeta de datos creada: {DATA_DIR}")
            except Exception as e:
                logger.error(f"No se pudo crear la carpeta de datos: {e}")
                return

        # Crear archivo JSON si no existe
        if not os.path.exists(RUTA):
            logger.warning('No existe archivo de notificaciones!')
            logger.debug('Intentando crear archivo notificaciones.json...')
            try:
                with open(RUTA, "w", encoding="utf-8") as f:
                    json.dump([], f, ensure_ascii=False, indent=4)
                logger.debug("Archivo de notificaciones creado.")
            except Exception as e:
                logger.error(f'NO SE PUDO CREAR ARCHIVO DE NOTIFICACIONES: {e}')            

    def guardar(self, data):
        """Agrega fecha y hora y guarda la notificación en JSON"""
        try:
            data["fecha_hora"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            todas = self._cargar_json()
            todas.append(data)
            with open(RUTA, "w", encoding="utf-8") as f:
                json.dump(todas, f, ensure_ascii=False, indent=4)
            logger.info(f"Notificación guardada: {data}")
        except Exception as e:
            logger.error(f"Error guardando notificación: {e}")

    def cargar(self, usuario):
        """Devuelve solo notificaciones de un usuario"""
        try:
            todas = self._cargar_json()
            return [n for n in todas if n.get("destinatario") == usuario]
        except Exception as e:
            logger.error(f"Error cargando notificaciones: {e}")
            return []

    def cargar_todas(self):
        """Devuelve todas las notificaciones sin filtrar"""
        try:
            return self._cargar_json()
        except Exception as e:
            logger.error(f"Error cargando todas las notificaciones: {e}")
            return []

    def marcar_como_leidas(self, usuario):
        """Marca todas las notificaciones de un usuario como leídas"""
        try:
            todas = self._cargar_json()
            for n in todas:
                if n.get("destinatario") == usuario:
                    n["leido"] = True
            with open(RUTA, "w", encoding="utf-8") as f:
                json.dump(todas, f, ensure_ascii=False, indent=4)
            logger.info(f"Notificaciones de {usuario} marcadas como leídas en JSON")
        except Exception as e:
            logger.error(f"Error marcando notificaciones como leídas: {e}")

    def _cargar_json(self):
        """Método interno para cargar todas las notificaciones desde JSON"""
        if not os.path.exists(RUTA):
            return []
        with open(RUTA, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logger.warning("Archivo JSON corrupto, retornando lista vacía")
                return []
