import os
import json
import logging
from diccionarios import PERMISOS_CATEGORIAS,ROLES_INICIALES
logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

RUTA_ROLES = os.path.join(DATA_DIR, "roles.json")





# -------------------- Funciones de roles --------------------

def cargar_roles():
    """Carga todos los roles desde roles.json, crea archivo si no existe"""
    if not os.path.exists(RUTA_ROLES):
        logger.warning('NO EXISTE ARCHIVO DE ROLES')
        logger.debug('intentando crear archivo con roles iniciales...')
        os.makedirs(DATA_DIR, exist_ok=True)
        # Guardar roles iniciales
        with open(RUTA_ROLES, "w", encoding="utf-8") as f:
            json.dump(ROLES_INICIALES, f, ensure_ascii=False, indent=2)
        logger.info(f"Archivo roles.json creado en {RUTA_ROLES} con roles iniciales")
    try:
        with open(RUTA_ROLES, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"No se pudo cargar roles.json: {e}")
        return []


def guardar_roles(data):
    """Guarda todos los roles en roles.json"""
    try:
        with open(RUTA_ROLES, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info("Roles guardados correctamente.")
    except Exception as e:
        logger.critical(f"No se pudo guardar roles.json: {e}")
        logger.exception(e)

def agregar_rol(nuevo_rol):
    """Agrega un rol nuevo si no existe (según id)"""
    roles = cargar_roles()
    if any(r["id"] == nuevo_rol["id"] for r in roles):
        return False, f"Ya existe un rol con ID {nuevo_rol['id']}"
    # Inicializar permisos por categoría si no existen
    nuevo_rol.setdefault("permisos", {cat: [] for cat in PERMISOS_CATEGORIAS})
    nuevo_rol.setdefault("vista", "")
    roles.append(nuevo_rol)
    guardar_roles(roles)
    return True, "Rol agregado correctamente"

def actualizar_rol(id_rol, datos_actualizados):
    """Actualiza un rol existente según su id"""
    roles = cargar_roles()
    for i, r in enumerate(roles):
        if r["id"] == id_rol:
            roles[i].update(datos_actualizados)
            guardar_roles(roles)
            logger.info(f"Rol {id_rol} actualizado correctamente.")
            return True
    logger.warning(f"Rol {id_rol} no encontrado para actualizar.")
    return False

def eliminar_rol(rol_id, user):
    from modelo.rolesUtils import _recalcular_permisos_usuario
    from modelo.CRU import cargarUsuarios, guardarUsuarios

    roles = cargar_roles()
    rol_a_eliminar = next((r for r in roles if r["id"] == rol_id), None)
    if not rol_a_eliminar:
        return False, "Rol no encontrado"

    # --- 1. Recopilar todos los permisos del rol ---
    permisos_a_eliminar = []
    permisos_dict = rol_a_eliminar.get("permisos", {})
    for cat, permisos in permisos_dict.items():
        for p in permisos:
            permiso_id = p["id"] if isinstance(p, dict) else p
            permisos_a_eliminar.append(permiso_id)

    # --- 2. Eliminar esos permisos de todos los roles restantes y usuarios ---
    usuarios_data = cargarUsuarios()
    usuarios_modificados = 0

    for r in roles:
        if r["id"] == rol_id:
            continue
        for cat in r.get("permisos", {}):
            r["permisos"][cat] = [
                p for p in r["permisos"][cat]
                if (p if isinstance(p, str) else p.get("id")) not in permisos_a_eliminar
            ]

    # Eliminar permisos de usuarios
    for tipo, lista in usuarios_data.items():
        for i, u in enumerate(lista):
            original_permisos = set(u.get("permisos", []))
            nuevos_permisos = [p for p in original_permisos if p not in permisos_a_eliminar]
            if set(nuevos_permisos) != original_permisos:
                u["permisos"] = nuevos_permisos
                usuarios_data[tipo][i] = u
                usuarios_modificados += 1

    # --- 3. Eliminar el rol del JSON ---
    nuevo_roles = [r for r in roles if r["id"] != rol_id]
    guardar_roles(nuevo_roles)
    guardarUsuarios(usuarios_data)

    logger.info(f"Rol {rol_id} eliminado correctamente. Permisos eliminados: {permisos_a_eliminar}. Usuarios modificados: {usuarios_modificados}")

    return True, "Rol eliminado, permisos y usuarios actualizados"
  

# -------------------- Funciones de permisos --------------------

def agregar_permiso_a_rol(rol_id, permiso, categoria="otros"):
    """Agrega un permiso a un rol en la categoría especificada"""
    if categoria not in PERMISOS_CATEGORIAS:
        return False, "Categoría inválida"
    roles = cargar_roles()
    rol = next((r for r in roles if r["id"] == rol_id), None)
    if not rol:
        return False, "Rol no encontrado"
    rol.setdefault("permisos", {cat: [] for cat in PERMISOS_CATEGORIAS})
    # Evitar duplicados
    if any(p["id"] == permiso["id"] for p in rol["permisos"][categoria]):
        return False, "Permiso ya existe en esta categoría"
    rol["permisos"][categoria].append(permiso)
    guardar_roles(roles)
    return True, "Permiso agregado correctamente"

def eliminar_permiso_de_rol(permiso_id):
    from modelo.CRU import cargarUsuarios, guardarUsuarios
    """
    Elimina permiso de TODOS los roles y además borra el permiso de todos los usuarios.
    """
    roles = cargar_roles()
    encontrado = False

    for r in roles:
        # asegurar la estructura de permisos
        if "permisos" not in r:
            continue
        for cat in list(r["permisos"].keys()):
            nueva = []
            for p in r["permisos"][cat]:
                # p puede ser str o dict
                if isinstance(p, dict) and p.get("id") == permiso_id:
                    encontrado = True
                    continue
                if isinstance(p, str) and p == permiso_id:
                    encontrado = True
                    continue
                nueva.append(p)
            r["permisos"][cat] = nueva

    if not encontrado:
        return False, "Permiso no encontrado en roles"

    # guardar roles
    guardar_roles(roles)
    logger.info("Permisos actualizados en roles.json tras eliminación de permiso.")

    # ahora borrar permiso de los usuarios
    usuarios_data = cargarUsuarios()
    afectados = 0
    for tipo, lista in usuarios_data.items():
        for i, u in enumerate(lista):
            if "permisos" in u and permiso_id in u["permisos"]:
                try:
                    u["permisos"] = [p for p in u["permisos"] if p != permiso_id]
                    usuarios_data[tipo][i] = u
                    afectados += 1
                except Exception:
                    logger.exception("Error limpiando permiso en usuario %s", u.get("email"))

    if afectados:
        guardarUsuarios(usuarios_data)
        logger.info("Permiso '%s' removido de %d usuarios", permiso_id, afectados)


    return True, f"Permiso eliminado correctamente. Usuarios afectados: {afectados}"

def actualizar_permiso(permiso_id, nuevo_nombre):
    """Actualiza el nombre de un permiso en todos los roles donde exista"""
    roles = cargar_roles()
    for r in roles:
        for cat in PERMISOS_CATEGORIAS:
            for p in r["permisos"][cat]:
                if p["id"] == permiso_id:
                    p["nombre"] = nuevo_nombre
    guardar_roles(roles)
    return True, "Permiso actualizado"

# -------------------- Función de permisos y roles para usuario --------------------

def aplicar_roles_y_permisos(usuario):
    from modelo.CRU import cargarUsuarios, guardarUsuarios
    """
    Aplica los roles y permisos al usuario y los guarda en usuarios.json.
    Convierte todas las categorías de permisos en una lista plana de IDs.
    """
    if not usuario.get("roles"):
        logger.warning(f"Usuario {usuario.get('email')} no tiene roles asignados.")
        return usuario

    data = cargarUsuarios()
    roles_def = cargar_roles()
    permisos_finales = set()  # usar set para evitar duplicados automáticamente

    # Recopilar todos los permisos según los roles del usuario
    for rol_def in roles_def:
        if rol_def["id"] in usuario["roles"]:
            permisos = rol_def.get("permisos", {})
            if isinstance(permisos, dict):
                for lista_perms in permisos.values():
                    for p in lista_perms:
                        if isinstance(p, dict) and "id" in p:
                            permisos_finales.add(p["id"])
                        elif isinstance(p, str):
                            permisos_finales.add(p)
            elif isinstance(permisos, list):
                for p in permisos:
                    if isinstance(p, dict) and "id" in p:
                        permisos_finales.add(p["id"])
                    elif isinstance(p, str):
                        permisos_finales.add(p)

    # Convertir set a lista
    permisos_finales = list(permisos_finales)

    encontrado = False
    for tipo, lista_usuarios in data.items():
        for i, u in enumerate(lista_usuarios):
            if u.get("email") == usuario.get("email"):
                u["roles"] = usuario.get("roles", [])
                u["permisos"] = permisos_finales
                data[tipo][i] = u
                try:
                    guardarUsuarios(data)
                    logger.info(f"Permisos actualizados para {usuario['email']}: {permisos_finales}")
                except Exception as e:
                    logger.error(f"No se pudo guardar usuarios al aplicar roles: {e}")
                    logger.exception(e)
                usuario = u
                encontrado = True
                break
        if encontrado:
            break

    if not encontrado:
        logger.warning(f"No se encontró usuario {usuario.get('email')} para aplicar roles.")
    
    return usuario
# al final del archivo rolesModel.py
def obtener_rol_por_id(rol_id):
    roles = cargar_roles()
    for r in roles:
        if r["id"] == rol_id:
            return r
    return None

def eliminar_rol_por_id(rol_id):
    from modelo.rolesUtils import _recalcular_permisos_usuario_obj 
    from modelo.CRU import cargarUsuarios, guardarUsuarios
    """
    Elimina un rol del archivo roles.json.
    Además lo elimina de todos los usuarios y recalcula sus permisos.
    """
    roles = cargar_roles()
    inicial_len = len(roles)
    roles = [r for r in roles if r.get("id") != rol_id]
    if len(roles) == inicial_len:
        return False, "Rol no encontrado"

    guardar_roles(roles)
    logger.info("Rol '%s' eliminado de roles.json", rol_id)

    # Remover rol de usuarios y recalcular permisos
    usuarios_data = cargarUsuarios()
    afectados = 0
    for tipo, lista in usuarios_data.items():
        for i, u in enumerate(lista):
            if "roles" in u and rol_id in u["roles"]:
                try:
                    u["roles"] = [r for r in u["roles"] if r != rol_id]
                    # recalcular permisos del usuario usando la función anterior
                    _recalcular_permisos_usuario_obj(u)
                    usuarios_data[tipo][i] = u
                    afectados += 1
                except Exception:
                    logger.exception("Error removiendo rol en usuario %s", u.get("email"))

    if afectados:
        guardarUsuarios(usuarios_data)
        logger.info("Rol '%s' removido de %d usuarios y permisos recalculados", rol_id, afectados)

    return True, f"Rol '{rol_id}' eliminado. Usuarios actualizados: {afectados}"



def obtener_permisos_desde_ids_roles(roles_ids):
    from modelo.CRU import normalizar_permisos
    """
    Dado un listado de ids de roles -> devuelve lista de permisos 'planos' (strings) sin duplicados.
    Usa normalizar_permisos() para soportar ambos formatos (dict/list).
    """
    roles = cargar_roles()
    permisos = []
    for rid in roles_ids:
        rol = next((r for r in roles if r.get("id") == rid), None)
        if rol:
            permisos.extend(normalizar_permisos(rol.get("permisos", {})))
    return sorted(list(set(permisos)))