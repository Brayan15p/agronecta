import os
import json
import qrcode
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Ruta donde se guardará pedidos.json
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
RUTA_PEDIDOS = os.path.join(DATA_DIR, "pedidos.json")

QRPEDIDOS_DIR = os.path.join(DATA_DIR, "qr_pedidos")

# -------------------------
#   ASEGURAR ARCHIVO
# -------------------------
def asegurar_archivo_pedidos():
    """Crea pedidos.json si no existe."""
    if not os.path.exists(RUTA_PEDIDOS):
        with open(RUTA_PEDIDOS, "w", encoding="utf-8") as f:
            json.dump({"pedidos": []}, f, indent=4, ensure_ascii=False)

def asegurar_carpeta_qr():
    if not os.path.exists(QRPEDIDOS_DIR):
        logger.warning('No existe carpeta de qrs!')
        logger.debug('Intentando crear carpeta de qrs...')
        try:
            os.makedirs(QRPEDIDOS_DIR)
            logger.info(f'Carpeta de configuración creada: {QRPEDIDOS_DIR}')
        except Exception as e:
            logger.error(f'No se pudo crear la carpeta de configuración: {e}')
            return    

# -------------------------
#   CARGAR Y GUARDAR
# -------------------------
def cargar_pedidos():
    asegurar_archivo_pedidos()
    with open(RUTA_PEDIDOS, "r", encoding="utf-8") as f:
        return json.load(f)


def guardar_pedidos(data):
    with open(RUTA_PEDIDOS, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


# -------------------------
#   GENERAR QR
# -------------------------
def generar_qr_pedido(pedido: dict):
    """
    Genera un código QR con TODA la información del pedido.
    Se convierte el pedido completo a JSON.
    """

    # Convertir todo el pedido a texto JSON
    contenido = json.dumps(pedido, ensure_ascii=False, indent=2)

    asegurar_carpeta_qr()

    # Ruta final del archivo QR
    ruta = os.path.join(QRPEDIDOS_DIR, f"pedido_{pedido['id_pedido']}.png")

    # Crear QR flexible (soporta mucha info)
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4
    )

    qr.add_data(contenido)
    qr.make(fit=True)
    img = qr.make_image(fill="black", back_color="white")
    img.save(ruta)

    return ruta


# -------------------------
#   REGISTRAR PEDIDO
# -------------------------
def registrar_pedido(restaurante: dict, campesino: dict, cultivo: dict, cantidad: int):
    """
    Registra un pedido completo, genera historial y el QR.
    - restaurante: dict con nombre, email…
    - campesino: dict con nombre, email…
    - cultivo: dict COMPLETO (debe venir con nombre, precio, tipo, etc.)
    - cantidad: int
    """

    # Crear ID único
    id_pedido = f"PED-{datetime.now().strftime('%Y%m%d%H%M%S')}"

    # Estructura completa del pedido
    pedido = {
        "id_pedido": id_pedido,
        "restaurante": restaurante.get("nombre"),
        "campesino": campesino.get("nombre"),
        "producto": cultivo.get('nombre'),               # ✔ GUARDAMOS EL OBJETO COMPLETO
        "cantidad": cantidad,
        "precio_total": cantidad * cultivo.get("precio", 0),
        "estado": "Pedido creado",
        "fecha": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "historial": [
            f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Pedido creado automáticamente."
        ]
    }

    # Generar QR con todo el pedido
    pedido["codigo_qr"] = generar_qr_pedido(pedido)

    # Guardar en JSON
    data = cargar_pedidos()
    data["pedidos"].append(pedido)
    guardar_pedidos(data)

    return pedido
